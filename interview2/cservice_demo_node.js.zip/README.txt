BAE云服务SDK示例说明

该示例涵盖了BAE的内置服务如：cache, counter, image, fetchurl, taskqueue, mysql, mongodb, redis
通过该示例可以了解内置服务的基本使用

注意：

1. 使用该示例时请您确保开启了cache，mysql，mongodb，redis服务

2. 请将申请的mysql, mongodb, redis数据库名替换掉./lib/sql.js, ./lib/mongo.js, ./lib/redis.js 文件中db_name变量值

3. 将该示例代码通过svn上传至申请的node.js应用中
